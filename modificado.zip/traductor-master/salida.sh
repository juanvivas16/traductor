#!/bin/bash
i=1
read n
j=1
echo $i
j=`expr $j + 1`
[ $j -le $i ]
whiledoi=`expr $i + 1`
echo \n
[ $i -le $n ]
whiledo