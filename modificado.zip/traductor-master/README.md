# traductor
Traductor de C a Shell Script
